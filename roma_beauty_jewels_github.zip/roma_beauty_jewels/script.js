// Store details: replace these two values before publishing.
const STORE_ADDRESS = 'Add your shop address here';
const STORE_PHONE = ''; // Use country code +91 and 10-digit number, without spaces.

document.getElementById('storeAddress').textContent = STORE_ADDRESS;
if (STORE_PHONE) {
  document.getElementById('storePhone').textContent = STORE_PHONE;
  document.getElementById('whatsappLink').href = `https://wa.me/${STORE_PHONE.replace(/\D/g, '')}`;
} else {
  document.getElementById('storePhone').textContent = 'Add your phone number in script.js';
  document.getElementById('whatsappLink').href = 'https://wa.me/';
}
document.getElementById('year').textContent = new Date().getFullYear();
document.getElementById('menuToggle').addEventListener('click', () => {
  document.getElementById('mainNav').classList.toggle('open');
});
document.querySelectorAll('#mainNav a').forEach(link => link.addEventListener('click', () => {
  document.getElementById('mainNav').classList.remove('open');
}));
