# Roma Beauty & Jewels

A responsive static storefront website built with HTML, CSS and JavaScript.

## Add shop details
Open `script.js` and replace:
- `STORE_ADDRESS` with the full shop address.
- `STORE_PHONE` with the WhatsApp number including country code, e.g. `919876543210`.

## Publish free with GitHub Pages
1. Sign in to GitHub and create a new **Public** repository named `roma-beauty-jewels`.
2. Upload `index.html`, `style.css`, `script.js`, and `README.md` to the repository root.
3. Open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select branch **main**, folder **/(root)**, then click **Save**.
6. Wait a minute or two. GitHub will show the live website URL in the Pages section.

Product photography is loaded from Unsplash URLs and requires an internet connection. Replace photos with your own product photos when available. Product images are illustrative; confirm actual stock and prices with the shop.
